<?php 

	include('config.php');

	$query = mysql_query("SELECT * FROM products ORDER BY product_title_general ASC");
	
	$result = array();
	
	while($row = mysql_fetch_assoc($query)){
		array_push($result,array(
			'product_title_general'=>$row['product_title_general']
		));
	}
	
	echo json_encode(array('result'=>$result));
	
	mysql_close($connect);

?>