<?php 
	
	include ('config.php');

	$id_pelanggan   = $_POST['id_pelanggan'];
	
	class emp{}
	
	if (empty($id_pelanggan)) { 
		$response = new emp();
		$response->success = 0;
		$response->message = "1. Data Tidak Terhapus: ".$id_pelanggan; 
		die(json_encode($response));
	} else {
		$query = mysql_query("DELETE FROM costumers WHERE costumer_id = '$id_pelanggan'");
		
		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Pelanggan Berhasil di Hapus";
			die(json_encode($response));
		} else{ 
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Tidak Terhapus";
			die(json_encode($response)); 
		}	
	}

?>