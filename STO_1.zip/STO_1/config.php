<?php 

	$server			= 'localhost';
	$user 			= 'drimhosc_sto2';
	$password 		= 'S4ndySTO2';
	$databaseName 	= 'drimhosc_sto1';

	$connect 		= mysql_connect($server, $user, $password) or die('Koneksi Gagal');
	mysql_select_db($databaseName) or die('Database Belum Siap');

?>