<?php 

	include ('config.php');

	$id_pelanggan   = $_POST['id_pelanggan'];

	$nama_pelanggan = $_POST['nama_pelanggan'];
	$alamat 		= $_POST['alamat'];
	$kecamatan 		= $_POST['kecamatan'];
	$kabupaten 		= $_POST['kabupaten'];
	$provinsi 		= $_POST['provinsi'];
	$kode_pos 		= $_POST['kode_pos'];
	$no_tlp 		= $_POST['no_tlp'];
	//$status_update 	= date('Y-m-d');

	class emp{}

	if (empty($nama_pelanggan) || empty($alamat) || empty($kecamatan) || empty($kabupaten) || empty($provinsi) || empty($kode_pos) || empty($no_tlp)){

		$response = new emp();
		$response->success = 0;
		$response->message = "Kolom Tidak Boleh Kosong";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("UPDATE costumers SET 
								costumer_name 			= '$nama_pelanggan', 
								costumer_address 		= '$alamat',
								costumer_sub_district 	= '$kecamatan',
								costumer_district 		= '$kabupaten',
								costumer_province 		= '$provinsi',
								costumer_postal_code 	= '$kode_pos',
								costumer_phone_number 	= '$no_tlp'
								WHERE costumer_id 		= '$id_pelanggan' 
							");
		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Pelanggan Berhasil di Update";
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Pelanggan Gagal di Update";
			die(json_encode($response));
		}

	}

?>