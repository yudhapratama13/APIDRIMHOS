<?php 

	include('config.php');

 
        
        $id_cs      = $_POST['id_cs'];
    	$tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        $namaPlg    = $_POST['namaPlg'];
        
        if($namaPlg == 'Pilih Semua'){
            $query =mysql_query("SELECT payment, SUM(total_price) AS tot_price FROM transactions WHERE user_id = '$id_cs' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.payment");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);    
        }
        else{
            
            $query_costumer = mysql_fetch_array(mysql_query("SELECT * FROM costumers WHERE costumer_name = '$namaPlg'"));
            $id_costumer = $query_costumer['costumer_id'];
            
            $query =mysql_query("SELECT payment, SUM(total_price) AS tot_price FROM transactions WHERE user_id = '$id_cs' AND customer_id = '$id_costumer' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.payment ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        
?>