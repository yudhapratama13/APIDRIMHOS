<?php 

	include('config.php');

	$id_cs      = $_POST['id_cs'];

	$query = mysql_query("SELECT * FROM transactions INNER JOIN costumers ON costumers.costumer_id = transactions.customer_id WHERE user_id = '$id_cs' ORDER BY transactions.customer_id DESC ");
	
	$result = array();
	
	while($row = mysql_fetch_assoc($query)){
		array_push($result,array(
			'costumer_name'=>$row['costumer_name']
		));
	}
	
	echo json_encode(array('result'=>$result));
	
	mysql_close($connect);

?>