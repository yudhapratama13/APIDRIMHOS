<?php 

	include('config.php');

 
        
        $id_cs      = $_POST['id_cs'];
    	$tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        $namaPlg    = $_POST['namaPlg'];
        
        if($namaPlg == 'Pilih Semua'){
            $query =mysql_query("SELECT product_title_for_recap, SUM(transaction_amount) AS total, product_point FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE user_id = '$id_cs' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions_amount.product_id ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);    
        }
        else{
            
            $query_costumer = mysql_fetch_array(mysql_query("SELECT * FROM costumers WHERE costumer_name = '$namaPlg'"));
            $id_costumer = $query_costumer['costumer_id'];
            
            $query =mysql_query("SELECT product_title_for_recap, SUM(transaction_amount) AS total, product_point FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE user_id = '$id_cs' AND customer_id = '$id_costumer' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions_amount.product_id ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        
?>