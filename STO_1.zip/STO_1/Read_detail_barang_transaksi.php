<?php 

	include('config.php');

    $id_transaksi   = $_POST['id_transaksi'];
            
    $query = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id INNER JOIN costumers ON costumers.costumer_id = transactions.customer_id WHERE transactions.transaction_id = '$id_transaksi' ");

	$json  = array();
	while ($row = mysql_fetch_assoc($query)) {
		$json[] = $row;
	}
	echo json_encode($json);
	mysql_close($connect);
        
        
?>